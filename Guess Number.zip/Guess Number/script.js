"use strict";

// document.querySelector(".number").textContent = 18;

document.querySelector(".guess").value = "";
let secreteNumber = Math.trunc(Math.random() * 20 + 1);
let score = 20;
document.querySelector(".score").textContent = score;
let highscore = 0;
// document.querySelector(".number").textContent = secreteNumber;
document.querySelector(".check").addEventListener("click", function () {
  const guessNumber = Number(document.querySelector(".guess").value);
  console.log(guessNumber);

  if (!guessNumber) {
    DisplayMessage("No Number!");
  }
  //Win
  else if (secreteNumber === guessNumber) {
    DisplayMessage("Correct Number 🏆");
    document.querySelector("body").style.backgroundColor = "green";
    document.querySelector(".number").style.width = "30rem";
    document.querySelector(".number").textContent = secreteNumber;
    if (score > highscore) {
      highscore = score;
      document.querySelector(".highscore").textContent = highscore;
    }
  }
  if (score > 1) {
      
      DisplayMessage(secreteNumber > guessNumber ? "Low Number" : "High Number");
    score--;
    document.querySelector(".score").textContent = score;
  } else {
    DisplayMessage( "You losed the game");
    score = 0;
    document.querySelector(".score").textContent = score;
  }


});

document.querySelector(".again").addEventListener("click", function () {
  score = 20;
  document.querySelector(".score").textContent = score;
  secreteNumber = Math.trunc(Math.random() * 20 + 1);
  DisplayMessage("Start guessing...");
  document.querySelector("body").style.backgroundColor = "black";
  document.querySelector(".number").style.width = "15rem";
  document.querySelector(".number").textContent = "?";
  document.querySelector(".guess").value = "";
});

function DisplayMessage(message){
  document.querySelector('.message').textContent = message;
}
